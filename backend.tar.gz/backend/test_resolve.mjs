import tseslint from 'typescript-eslint';
console.log('Successfully resolved typescript-eslint');
console.log(tseslint.configs.recommended);
